using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour
{
  public ItemObject itemObject; // Reference to the ItemObject scriptable object
}
